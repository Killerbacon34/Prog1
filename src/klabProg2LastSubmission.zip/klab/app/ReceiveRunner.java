/**
 * Author:      Alex DeVries
 * Assignment:  Program 2
 * Class:       CSI 4321 Data Communications
 */
package klab.app;

import klab.serialization.*;

import java.io.File;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * ReceiveRunner class which implements runnable to decode
 * Response and Search objects to the socket
 */
public class ReceiveRunner implements Runnable {
    /**
     * the file id length
     */
    private static final int FILE_ID_RANDOM_LEN = 4;
    /**
     * the largest unsigned integer value
     */
    private static final long LARGEST_UNSIGNED_INT = 4294967296L;
    /**
     * the smallest unsigned integer value
     */
    private static final long SMALLEST_UNSIGNED_INT = 0L;
    /**
     * The socket to which the messages are decoded and encoded to
     */
    private final Socket socket;
    /**
     * The directory path given to search for the files
     */
    private final String directoryPath;
    /**
     * a map of file names to their random file IDs
     */
    private final Map<String, Long> fileMapping;

    /**
     * The constructor for the ReceiveRunner object
     *
     * @param socket        the socket to be used
     * @param directoryPath the directory path for file searching
     */
    ReceiveRunner(Socket socket, String directoryPath) {
        this.socket = socket;
        this.directoryPath = directoryPath;
        this.fileMapping = new HashMap<>();
        updateMapping();
    }

    /**
     * A function to update the mapping of random file ids to their names
     * in case the current directory changes its contents
     */
    public void updateMapping() {
        try {
            File directory = new File(directoryPath);
            File[] files = directory.listFiles();
            for (File file : files) {
                if (!fileMapping.containsKey(file.getName())) {
                    long randomID = generateRandomFileID(fileMapping);
                    fileMapping.put(file.getName(), randomID);
                }
            }
        } catch (NullPointerException | SecurityException e) {
            Logger.getLogger("Node.Log").log(Level.WARNING,
                    "Error with the file system: "
                            + e.getLocalizedMessage(), e);
        }
    }

    /**
     * Print the response to the screen based on a given response instance
     * @param response the response to be printed to the screen
     */
    public void printResponse(Response response) {
        if (Node.getSearchMap()
                .containsKey(Arrays.toString(response.getID()))) {
            synchronized (System.out) {
                System.out.println("Search response for " + Node.getSearchMap()
                            .get(Arrays.toString(response.getID())) + ":");
                System.out.println("Download host: " +
                                response.getResponseHost().getAddress() + ":"
                        + response.getResponseHost().getPort());
                StringBuilder formatted = new StringBuilder();
                for (Result r : response.getResultList()) {
                    formatted.append("      ");
                    formatted.append(r.getFileName());
                    formatted.append(": ID ");
                    for (byte b : r.getFileID()) {
                        formatted.append(String.format("%02X", b));
                    }
                    formatted.append(" (");
                    formatted.append(r.getFileSize());
                    formatted.append(" bytes)\n");
                }
                System.out.println(formatted);
            }
        }
    }

    /**
     * convert an unsigned integer to a byte array
     * @param number the value to convert to a byte array
     * @return the file ID as a byte array
     */
    public byte[] convertToByteArray(long number) {
        byte[] value = new byte[FILE_ID_RANDOM_LEN];
        for (int i = FILE_ID_RANDOM_LEN - 1; i >= 0; i--) {
            value[i] = (byte) (number & 0xFF);
            number >>= 8;
        }
        return value;
    }

    /**
     * Generate a random file id and avoid collisions if encountered
     * @param map the map holding the file names and their random file ids
     * @return the randomly generated file id
     */
    public long generateRandomFileID(Map<String, Long> map) {
        long otherID = (long) (new Random().nextDouble()
                                * LARGEST_UNSIGNED_INT + 1);
        for (long value : map.values()) {
            if (value == otherID) {
                if (otherID == LARGEST_UNSIGNED_INT) {
                    otherID = SMALLEST_UNSIGNED_INT;
                } else {
                    otherID++;
                }
            }
        }
        return otherID;
    }


    /**
     * Run method within the ReceiveRunner instance to decode either
     * a search or a response instance to the socket inputStream
     */
    public void run() {
        Logger logger = Logger.getLogger("Node.Log");
        while (!socket.isClosed()) {
            try {
                MessageInput socketInput =
                        new MessageInput(socket.getInputStream());
                MessageOutput socketOutput =
                        new MessageOutput(socket.getOutputStream());
                updateMapping();
                Message message = Message.decode(socketInput);
                //If message is a response instance
                if (message instanceof Response response) {
                    logger.log(Level.INFO, "Received: " + response);
                    printResponse(response);
                }
                //If the message is a search instance
                else if (message instanceof Search search) {
                    Response response = new Response(search.getID(),
                            50, RoutingService.BREADTHFIRST,
                            new InetSocketAddress(Inet4Address.
                                    getLocalHost().getHostAddress(),
                                    socket.getLocalPort()));

                    File directory = new File(directoryPath);
                    File[] files = directory.listFiles((dir, name) ->
                            name.contains(search.getSearchString()));
                    if (!search.getSearchString().isEmpty() && files != null) {
                        logger.log(Level.INFO, "Received: " + search);
                        for (File file : files) {
                            if (fileMapping.containsKey(file.getName())) {
                                response.addResult(
                                        new Result(convertToByteArray(
                                        fileMapping.get(file.getName())),
                                        file.length(), file.getName()));
                            }
                        }
                    }
                    Node.getService().submit(new SenderRunner(
                                        response, socketOutput));
                }
            } catch (BadAttributeValueException e) {
                logger.log(Level.WARNING,
                        "Invalid message: " + e.getLocalizedMessage(), e);
            } catch (IOException e) {
                logger.log(Level.INFO,
                        "Closing node: " + e.getLocalizedMessage(), e);
                break;
            }
        }
    }
}