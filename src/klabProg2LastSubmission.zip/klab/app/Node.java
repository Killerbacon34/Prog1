/**
 * Author:      Alex DeVries
 * Assignment:  Program 2
 * Class:       CSI 4321 Data Communications
 */
package klab.app;

import klab.serialization.*;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.Socket;
import java.net.SocketException;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.*;

/**
 * Node class for processing user input and thread actions
 */
public class Node {
    /**
     * Node default constructor
     */
    Node(){

    }
    /**
     * Random ID Length
     */
    private static final int RANDOM_ID_LENGTH = 15;
    /**
     * the number of command line arguments
     */
    private static final int ARG_LENGTH = 3;
    /**
     * Arbitrary TTL value
     */
    private static final int ARBITRARY_TTL = 50;
    /**
     * Logger instance used to log to a file
     */
    private static final Logger LOGGER = Logger.getLogger("Node.Log");

    /**
     * Map for searching with the searchID as the key and the search
     * string as the value
     */
    private static final Map<String,String> searchMap = new HashMap<>();
    /**
     * ExecutorService for managing senderRunner instances
     */
    private static final ExecutorService service =
                         Executors.newSingleThreadExecutor();

    /**
     * Static block of code used to create settings for the logger.
     */
    static{
        FileHandler fh;
        ConsoleHandler c;
        try {
            fh = new FileHandler(System.getProperty("user.dir")+"\\node.log");
            c = new ConsoleHandler();
            fh.setLevel(Level.ALL);
            c.setLevel(Level.WARNING);
            SimpleFormatter formatter = new SimpleFormatter();
            fh.setFormatter(formatter);
            LOGGER.addHandler(fh);
            LOGGER.addHandler(c);
            LOGGER.setUseParentHandlers(false);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Function to add Searches to a map
     * @param search the search to add to the map
     */
    public static synchronized void addToSearchMap(Search search){
        byte[] temp = search.getID();
        String s = Arrays.toString(temp);
        searchMap.put(s,search.getSearchString());
    }

    /**
     * Get the SearchMap instance from node
     * @return the SearchMap instance
     */
    public static Map<String, String> getSearchMap(){
        return searchMap;
    }

    /**
     * Get the ExecutorService instance from the node
     * @return the ExecutorService instance from node
     */
    public static ExecutorService getService(){
        return service;
    }

    /**
     * the main function within the Node class
     * @param args the command line arguments to be passed in
     * @throws IOException if any parsing errors occur
     * @throws BadAttributeValueException if any invalid message parameters
     *                                    are set
     */
    public static void main(String[] args)
                    throws IOException, BadAttributeValueException {
        Scanner scanner = new Scanner(System.in);
        String currentValue;
        boolean errorPresent = false;
        Socket socket = null;

        if (args.length != ARG_LENGTH) {
            System.err.println("Argument length invalid");
            errorPresent = true;
        }
        String directoryPath = args[0];
        String neighborName = args[1];
        int neighborPort = Integer.parseInt(args[2]);
        socket = new Socket(neighborName, neighborPort);
        LOGGER.log(Level.INFO, "Entering in Node through socket: " +
                                Inet4Address.getLocalHost().getHostAddress() +
                                ":" + socket.getLocalPort());
        MessageOutput socketOutput =
                            new MessageOutput(socket.getOutputStream());
        Thread thread = new Thread(new ReceiveRunner(socket, directoryPath));
        thread.start();
        while (!errorPresent) {
            try {
                System.out.print("> ");
                currentValue = scanner.nextLine();
                if (currentValue.equalsIgnoreCase("exit")) {
                    System.out.println("Exiting program...");
                    socket.close();
                    service.close();
                    scanner.close();
                    break;
                }
                byte[] b = new byte[RANDOM_ID_LENGTH];
                new Random().nextBytes(b);
                Search search = new Search(b, ARBITRARY_TTL,
                                RoutingService.BREADTHFIRST, currentValue);
                service.submit(new SenderRunner(search, socketOutput));
            } catch (RuntimeException | SocketException e) {
                LOGGER.log(Level.SEVERE, "Unable to communicate: "
                                            + e.getLocalizedMessage(), e);
                socket.close();
                service.close();
                scanner.close();
            } catch (BadAttributeValueException | IOException x) {
                System.err.println("An error occurred: " + x.getMessage());
            }
        }
    }

}
