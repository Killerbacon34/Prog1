/**
 * Author:      Alex DeVries
 * Assignment:  Program 2
 * Class:       CSI 4321 Data Communications
 */
package klab.app;

import klab.serialization.*;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * SenderRunner class which implements runnable to encode
 * Response and Search objects to the socket
 */
public class SenderRunner implements Runnable{
    /**
     * Message instance to be encoded
     */
    private final Message message;
    /**
     * The messageOutput Instance to be used with the socket
     */
    private final MessageOutput socketOutput;


    /**
     * Constuctor for the SenderRunner class
     * @param message the message instance to be encoded
     * @param socketOutput the MessageOutput instance to be encoded to
     */
    SenderRunner(Message message, MessageOutput socketOutput){
        this.message = message;
        this.socketOutput = socketOutput;
    }

    /**
     * Run method within the SenderRunner instance to encode either
     * a search or a response instance to the socket outputStream
     */
    public void run() {
        try {
            if (message instanceof Search search) {
                search.encode(socketOutput);
                Logger.getLogger("Node.Log")
                                .log(Level.INFO, "Sending: " + search);
                Node.addToSearchMap(search);
            }
            else if (message instanceof Response response){
                response.encode(socketOutput);
                Logger.getLogger("Node.Log")
                                .log(Level.INFO, "Sending: " + response);
            }
        } catch (IOException e) {
            Logger logger = Logger.getLogger("Node.Log");
            logger.log(Level.WARNING,
                    "Unable to communicate: " + e.getMessage(), e);
        }
    }

}
