/**
 * Author:      Alex DeVries
 * Assignment:  Program 2
 * Class:       CSI 4321 Data Communications
 */
package klab.app;

import klab.serialization.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Node {
    private static final Logger logger = Logger.getLogger(Node.class.getName());

    public static void Searching(String currentValue, Socket socket) throws IOException, BadAttributeValueException {
        long x = currentValue.length();
        byte[] enc = new byte[] { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0};
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        MessageOutput out = new MessageOutput(output);
        out.writeBytes(enc);
        out.writeUnsignedInt(x,2);
        out.writeBytes(currentValue.getBytes(StandardCharsets.US_ASCII));
        Search r = (Search) Message.decode(new MessageInput(new ByteArrayInputStream(output.toByteArray())));
        socket.getOutputStream().write(r.toString().getBytes(StandardCharsets.US_ASCII));
        socket.getOutputStream().write("\n".getBytes(StandardCharsets.US_ASCII));
    }
    public static void Responding(String currentValue, Socket socket) throws IOException {
        byte[] enc = new byte[] {2, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 50, 0, 0};
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        MessageOutput out = new MessageOutput(output);
        socket.getOutputStream().write(("Search response for " + currentValue + ":\n").getBytes(StandardCharsets.US_ASCII));
        socket.getOutputStream().write(("Download host: " + socket.getLocalAddress() + ":"  + socket.getLocalPort() + "\n").getBytes(StandardCharsets.US_ASCII));

    }
    public static void main(String args[]) throws IOException, BadAttributeValueException {

        Socket socket = new Socket("129.62.148.8", 24680);
        System.out.println("Port: " + socket.getLocalPort());
        System.out.println("Address: " + socket.getLocalAddress());
        logger.setLevel(Level.INFO);
        logger.severe("This is a severe message");
        socket.getOutputStream().write("TEST MESSAGE\n".getBytes(StandardCharsets.US_ASCII));
        Scanner scanner = new Scanner(System.in);
        String currentValue;
//        File directoryPath = new File("~/home/csi/d/devriesa");
//        File[] contents = directoryPath.listFiles();
//        for(File f : contents){
//            System.out.println(f.getName());
//        }
        while(true){
            currentValue = scanner.nextLine();
            if (currentValue.equalsIgnoreCase("exit")) {
                System.out.println("Exiting program...");
                break;
            }
            Searching(currentValue, socket);
            Responding(currentValue, socket);
        }
        scanner.close();

    }
}
